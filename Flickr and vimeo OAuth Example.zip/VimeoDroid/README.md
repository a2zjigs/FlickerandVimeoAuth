#Vimeo Droid

Vimeo Droid is an Android application that interfaces with Vimeo.com.  

## Instructions
- Register for a developer account with Vimeo.com http://vimeo.com/api
- Register for an API Application
- Replace your the values for CONSUMER_KEY and CONSUMER_SECRET in the Authentication class with your Consumer Key / Consumer Secret 
	- (I really need to not have these hard coded)
	
## TODO
- Implement User info screen
- Find a better way to play videos, some devices can't play the higher quality videos on Vimeo
- Update UI