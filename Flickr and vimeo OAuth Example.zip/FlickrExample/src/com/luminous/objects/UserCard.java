package com.luminous.objects;

public class UserCard {

	public String name;
	public String url;
	public int upVotes;
	public int downVotes;

}
